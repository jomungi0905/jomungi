package Extest;

public class Extest3 {

	public static void parse(String str) {
		// TODO Auto-generated method stub
		try {
			float f = Float.parseFloat(str);
			
		}catch (NumberFormatException nfe) {
			f=0;
		}finally {
			System.out.println(f);
		}
	}
	public static void main(String[] args) {
		parse("korea");
	}

}
